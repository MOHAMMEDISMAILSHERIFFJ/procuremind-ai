import pandas as pd
import json
import random
import re

INPUT = r"C:\Users\NITHIN RAGUNATH\Downloads\prediction_data.csv\prediction_data.csv"

TRAIN_OUTPUT = "negotiation_train.jsonl"
VALID_OUTPUT = "negotiation_validation.jsonl"

SYSTEM_PROMPT = """You are an AI procurement negotiation agent representing a company.

Your objective is to obtain the best possible purchasing terms while protecting the company's requirements.

You should:
- negotiate professionally and respectfully
- request better pricing when appropriate
- ask for bulk discounts
- ask for better payment or delivery terms when relevant
- compare alternatives when information is available
- avoid unnecessary purchases
- never invent vendor facts
- never claim a discount was accepted unless the vendor actually accepted it
- ask for missing information when necessary
- explain the next recommended procurement action
"""

def extract_context(text):
    match = re.search(
        r"Product Context:\s*(.*?)(?:\s{2,}|$)",
        text,
        re.IGNORECASE
    )

    if match:
        return match.group(1).strip()

    return "Unknown product"

def remove_context(text):
    return re.sub(
        r"Product Context:\s*.*?(?=\s{2,}|$)",
        "",
        text,
        flags=re.IGNORECASE
    ).strip()

def extract_price(text):
    patterns = [
        r'[$₹]\s?[\d,]+(?:\.\d+)?',
        r'(?:USD|INR)\s?[\d,]+(?:\.\d+)?',
        r'\b\d{3,}(?:,\d{3})*(?:\.\d+)?\b'
    ]

    for pattern in patterns:
        match = re.search(pattern, text, re.IGNORECASE)

        if match:
            return match.group(0)

    return None

def create_response(message, product):

    price = extract_price(message)

    lower = message.lower()

    # Vendor refuses negotiation
    if (
        "can't compromise" in lower
        or "cannot compromise" in lower
        or "already agreed" in lower
        or "cannot accept" in lower
        or "can't accept" in lower
    ):
        return (
            "I understand your position. However, we need to stay within "
            "our procurement budget. Could you provide your best final price "
            "or suggest an alternative configuration that offers better value? "
            "If the price cannot be reduced, please share any additional "
            "commercial benefits you can offer."
        )

    # Vendor gives a price
    if price:
        return (
            f"Thank you for the quotation for {product}. "
            f"The quoted price of {price} is noted. "
            "Before we proceed, please provide your best possible price. "
            "Since this is a business purchase, please consider a bulk "
            "discount or improved commercial terms. "
            "Also confirm whether there is any flexibility on payment, "
            "delivery, warranty, or included accessories."
        )

    # Product / specification discussion
    if any(
        word in lower
        for word in [
            "what size",
            "what is the",
            "how is",
            "quality",
            "warranty",
            "included",
            "comes with",
            "specification"
        ]
    ):
        return (
            f"Thank you for the information about {product}. "
            "Before making a purchase decision, please confirm the "
            "complete specifications, warranty coverage, included items, "
            "delivery time, and the best available business price."
        )

    # Generic negotiation
    return (
        f"Thank you for the information regarding {product}. "
        "We are evaluating the purchase from a procurement perspective. "
        "Please provide your best commercial offer, including any bulk "
        "discount, warranty, delivery commitment, payment terms, and "
        "additional value you can provide. "
        "We will evaluate the total value before making a decision."
    )


df = pd.read_csv(INPUT)

examples = []

for text in df["Text"].dropna():

    text = str(text).strip()

    if len(text) < 30:
        continue

    if len(text) > 2000:
        continue

    product = extract_context(text)
    message = remove_context(text)

    if len(message) < 15:
        continue

    assistant = create_response(message, product)

    user_prompt = f"""Product:
{product}

Vendor message:
{message}

Act as the company's procurement negotiator.
Respond professionally and try to improve the purchasing terms."""

    examples.append({
        "messages": [
            {
                "role": "system",
                "content": SYSTEM_PROMPT
            },
            {
                "role": "user",
                "content": user_prompt
            },
            {
                "role": "assistant",
                "content": assistant
            }
        ]
    })


# Remove duplicates
unique = {}

for example in examples:
    key = json.dumps(example, sort_keys=True)
    unique[key] = example

examples = list(unique.values())

random.seed(42)
random.shuffle(examples)

split = int(len(examples) * 0.90)

train = examples[:split]
validation = examples[split:]

with open(TRAIN_OUTPUT, "w", encoding="utf-8") as f:
    for example in train:
        f.write(json.dumps(example, ensure_ascii=False) + "\n")

with open(VALID_OUTPUT, "w", encoding="utf-8") as f:
    for example in validation:
        f.write(json.dumps(example, ensure_ascii=False) + "\n")

print("=" * 50)
print("NEGOTIATION DATASET CREATED")
print("=" * 50)
print("Original records:", len(df))
print("Negotiation examples:", len(examples))
print("Training:", len(train))
print("Validation:", len(validation))
print()
print("Created:")
print(TRAIN_OUTPUT)
print(VALID_OUTPUT)