import torch
from datasets import load_dataset
from transformers import (
    AutoTokenizer,
    AutoModelForCausalLM,
    BitsAndBytesConfig,
)
from peft import (
    LoraConfig,
    prepare_model_for_kbit_training,
)
from trl import SFTTrainer, SFTConfig


# ============================================
# CONFIG
# ============================================

MODEL_NAME = "Qwen/Qwen2.5-3B-Instruct"

TRAIN_FILE = "negotiation_train.jsonl"
VALID_FILE = "negotiation_validation.jsonl"

OUTPUT_DIR = "./negotiator-qwen"

print("=" * 60)
print("AI PROCUREMENT NEGOTIATOR - QLoRA TRAINING")
print("=" * 60)

# ============================================
# GPU CHECK
# ============================================

if not torch.cuda.is_available():
    raise RuntimeError("CUDA GPU not detected!")

print("GPU:", torch.cuda.get_device_name(0))
print("VRAM:", round(
    torch.cuda.get_device_properties(0).total_memory / 1024**3, 2
), "GB")

# ============================================
# DATASET
# ============================================

print("\nLoading dataset...")

dataset = load_dataset(
    "json",
    data_files={
        "train": TRAIN_FILE,
        "validation": VALID_FILE
    }
)

print("Training examples:", len(dataset["train"]))
print("Validation examples:", len(dataset["validation"]))

# ============================================
# TOKENIZER
# ============================================

print("\nLoading tokenizer...")

tokenizer = AutoTokenizer.from_pretrained(
    MODEL_NAME,
    use_fast=True
)

if tokenizer.pad_token is None:
    tokenizer.pad_token = tokenizer.eos_token

# ============================================
# 4-BIT QLoRA CONFIG
# ============================================

print("\nConfiguring 4-bit QLoRA...")

compute_dtype = torch.float16

bnb_config = BitsAndBytesConfig(
    load_in_4bit=True,
    bnb_4bit_quant_type="nf4",
    bnb_4bit_use_double_quant=True,
    bnb_4bit_compute_dtype=compute_dtype,
)

# ============================================
# LOAD MODEL
# ============================================

print("\nLoading Qwen2.5-3B...")

model = AutoModelForCausalLM.from_pretrained(
    MODEL_NAME,
    quantization_config=bnb_config,
    device_map="auto",
    torch_dtype=compute_dtype,
)

model.config.use_cache = False

# Prepare quantized model for LoRA training
model = prepare_model_for_kbit_training(model)

print("Model loaded.")

# ============================================
# LoRA CONFIG
# ============================================

print("\nConfiguring LoRA...")

lora_config = LoraConfig(
    r=8,
    lora_alpha=16,
    lora_dropout=0.05,
    bias="none",
    task_type="CAUSAL_LM",
    target_modules="all-linear",
)

# ============================================
# TRAINING CONFIG
# ============================================

training_args = SFTConfig(

    output_dir=OUTPUT_DIR,

    # GPU memory
    per_device_train_batch_size=1,
    per_device_eval_batch_size=1,

    gradient_accumulation_steps=8,

    # Training
    num_train_epochs=1,
    max_steps=100,

    learning_rate=2e-4,

    lr_scheduler_type="cosine",

    weight_decay=0.01,

    # Precision
    fp16=False,
    bf16=False,

    # Memory
    gradient_checkpointing=True,

    # Sequence length
    max_length=300,

    # Dataset
    packing=False,

    # Evaluation
    eval_strategy="steps",
    eval_steps=500,

    # Saving
    save_strategy="steps",
    save_steps=500,
    save_total_limit=2,

    # Logging
    logging_steps=10,

    # Optimizer
    optim="paged_adamw_32bit",

    # Don't upload anything
    report_to="none",

    # Reproducibility
    seed=42,

    # Disable cache
    use_cache=False,
)

# ============================================
# TRAINER
# ============================================

print("\nCreating trainer...")

trainer = SFTTrainer(

    model=model,

    args=training_args,

    train_dataset=dataset["train"],

    eval_dataset=dataset["validation"],

    processing_class=tokenizer,

    peft_config=lora_config,
)

# ============================================
# START TRAINING
# ============================================

print("\n" + "=" * 60)
print("STARTING TRAINING")
print("=" * 60)

trainer.train()

# ============================================
# SAVE
# ============================================

print("\nSaving negotiator adapter...")

trainer.save_model(OUTPUT_DIR)

tokenizer.save_pretrained(OUTPUT_DIR)

print("\n" + "=" * 60)
print("TRAINING COMPLETE!")
print("=" * 60)

print("Model adapter saved to:")
print(OUTPUT_DIR)

print("\nYou can now test the trained negotiator.")
# QUICK DEMO DATASET
dataset["train"] = dataset["train"].select(
    range(min(200, len(dataset["train"])))
)

dataset["validation"] = dataset["validation"].select(
    range(min(50, len(dataset["validation"])))
)

print("Training examples:", len(dataset["train"]))
print("Validation examples:", len(dataset["validation"]))
