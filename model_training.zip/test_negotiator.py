import torch
from transformers import AutoTokenizer, AutoModelForCausalLM
from peft import PeftModel

MODEL_NAME = "Qwen/Qwen2.5-3B-Instruct"
ADAPTER_PATH = "./negotiator-qwen"

print("Loading model...")

tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)

model = AutoModelForCausalLM.from_pretrained(
    MODEL_NAME,
    torch_dtype=torch.float16,
    device_map="auto"
)

model = PeftModel.from_pretrained(
    model,
    ADAPTER_PATH
)

model.eval()

print("Model loaded!")
print("\nType your negotiation question.")
print("Type 'exit' to stop.\n")

while True:

    question = input("YOU: ")

    if question.lower() == "exit":
        break

    prompt = f"""You are a professional company procurement negotiator.

Your goal is to reduce unnecessary purchasing cost while protecting the company's requirements.

Never invent prices, specifications, discounts, or vendor information.

Vendor/customer message:
{question}

Respond professionally as the procurement negotiator.
"""

    inputs = tokenizer(
        prompt,
        return_tensors="pt"
    ).to(model.device)

    with torch.no_grad():
        outputs = model.generate(
            **inputs,
            max_new_tokens=200,
            temperature=0.7,
            do_sample=True,
            top_p=0.9,
            pad_token_id=tokenizer.eos_token_id
        )

    response = tokenizer.decode(
        outputs[0][inputs["input_ids"].shape[1]:],
        skip_special_tokens=True
    )

    print("\nAI:", response.strip())
    print()