import os
import pandas as pd
import torch

# ============================================================
# AI PROCUREMENT NEGOTIATOR - QUICK EXCEL TRAINING
# Dataset: data.xlsx
# Your Excel file contains ONE column: "Text"
# Designed for an RTX 4050 Laptop GPU and ~1 hour maximum.
# ============================================================

# Prevent Accelerate from enabling mixed precision automatically.
os.environ["ACCELERATE_MIXED_PRECISION"] = "no"

from datasets import Dataset, DatasetDict
from transformers import (
    AutoTokenizer,
    AutoModelForCausalLM,
    BitsAndBytesConfig,
)
from peft import (
    LoraConfig,
    prepare_model_for_kbit_training,
)
from trl import SFTTrainer, SFTConfig


# ============================================================
# SETTINGS
# ============================================================

MODEL_NAME = "Qwen/Qwen2.5-3B-Instruct"
EXCEL_FILE = "./data.xlsx"
OUTPUT_DIR = "./negotiator-qwen-excel"

# QUICK TRAINING
TRAIN_SAMPLES = 500
VALIDATION_SAMPLES = 50
MAX_STEPS = 100

print("=" * 60)
print("AI PROCUREMENT NEGOTIATOR")
print("=" * 60)


# ============================================================
# CHECK GPU
# ============================================================

print("\nChecking GPU...")

if not torch.cuda.is_available():
    raise RuntimeError(
        "CUDA GPU was not detected. Make sure your NVIDIA GPU/driver "
        "and CUDA-enabled PyTorch are installed."
    )

print("CUDA: AVAILABLE")
print("GPU:", torch.cuda.get_device_name(0))


# ============================================================
# LOAD EXCEL
# ============================================================

print("\nLoading Excel dataset...")

if not os.path.exists(EXCEL_FILE):
    raise FileNotFoundError(
        f"Could not find {EXCEL_FILE}. Put data.xlsx in the same "
        "folder as train_excel.py."
    )

df = pd.read_excel(EXCEL_FILE)

print("Excel loaded.")
print("Total rows:", len(df))
print("Columns:", list(df.columns))


# ============================================================
# USE THE ACTUAL DATASET FORMAT
# ============================================================
# The uploaded Excel file has:
#
#   Text
#
# There are no separate vendor/assistant columns.
# Therefore, use the existing Text column directly.

if "Text" not in df.columns:
    raise ValueError(
        "The Excel file must contain a column named 'Text'. "
        f"Found: {list(df.columns)}"
    )

df = df.dropna(subset=["Text"]).copy()
df["text"] = df["Text"].astype(str).str.strip()

# Remove empty text rows
df = df[df["text"].str.len() > 0].reset_index(drop=True)

# Shuffle before selecting the small training subset
df = df.sample(frac=1, random_state=42).reset_index(drop=True)

if len(df) < TRAIN_SAMPLES + VALIDATION_SAMPLES:
    TRAIN_SAMPLES = max(1, int(len(df) * 0.90))
    VALIDATION_SAMPLES = len(df) - TRAIN_SAMPLES

train_df = df.iloc[:TRAIN_SAMPLES].copy()
validation_df = df.iloc[
    TRAIN_SAMPLES:TRAIN_SAMPLES + VALIDATION_SAMPLES
].copy()

print("\nFinal dataset:")
print("Available examples:", len(df))
print("Training examples:", len(train_df))
print("Validation examples:", len(validation_df))

dataset = DatasetDict({
    "train": Dataset.from_pandas(
        train_df[["text"]],
        preserve_index=False
    ),
    "validation": Dataset.from_pandas(
        validation_df[["text"]],
        preserve_index=False
    ),
})

print("\nExample:")
print(dataset["train"][0]["text"][:700])


# ============================================================
# TOKENIZER
# ============================================================

print("\nLoading tokenizer...")

tokenizer = AutoTokenizer.from_pretrained(
    MODEL_NAME,
    trust_remote_code=True,
)

if tokenizer.pad_token is None:
    tokenizer.pad_token = tokenizer.eos_token

tokenizer.padding_side = "right"


# ============================================================
# 4-BIT QLoRA
# ============================================================

print("\nConfiguring 4-bit QLoRA...")

bnb_config = BitsAndBytesConfig(
    load_in_4bit=True,
    bnb_4bit_quant_type="nf4",
    bnb_4bit_use_double_quant=True,
    bnb_4bit_compute_dtype=torch.float16,
)


# ============================================================
# LOAD MODEL
# ============================================================

print("\nLoading Qwen2.5-3B...")

model = AutoModelForCausalLM.from_pretrained(
    BASE_MODEL,
    quantization_config=bnb_config,
    device_map={"": 0},
    torch_dtype=torch.float16,
    trust_remote_code=True,
) 
model.config.use_cache = False

model = prepare_model_for_kbit_training(model)

print("Model loaded.")


# ============================================================
# LoRA
# ============================================================

print("\nConfiguring LoRA...")

lora_config = LoraConfig(
    r=16,
    lora_alpha=32,
    lora_dropout=0.05,
    bias="none",
    task_type="CAUSAL_LM",
    target_modules=[
        "q_proj",
        "k_proj",
        "v_proj",
        "o_proj",
        "gate_proj",
        "up_proj",
        "down_proj",
    ],
)


# ============================================================
# TRAINING CONFIG
# ============================================================

print("\nConfiguring training...")

training_args = SFTConfig(
    output_dir=OUTPUT_DIR,

    # Quick training
    num_train_epochs=1,
    max_steps=MAX_STEPS,

    # RTX 4050 friendly
    per_device_train_batch_size=1,
    per_device_eval_batch_size=1,
    gradient_accumulation_steps=8,

    # Learning
    learning_rate=2e-4,
    lr_scheduler_type="cosine",
    weight_decay=0.01,

    # IMPORTANT:
    # Do not enable fp16/bf16 Trainer mixed precision.
    # The QLoRA model itself uses float16 compute.
    fp16=False,
    bf16=False,

    # Memory
    gradient_checkpointing=True,

    # Evaluation/save
    eval_strategy="steps",
    eval_steps=50,
    save_strategy="steps",
    save_steps=100,
    save_total_limit=1,

    # Logging
    logging_steps=10,
    report_to="none",

    # Dataset
    packing=False,
    max_length=512,

    # Reproducibility
    seed=42,

    # Do not use dataset_text_field here.
    # Your installed TRL version rejected that argument.
)


# ============================================================
# TRAINER
# ============================================================

print("\nCreating trainer...")

trainer = SFTTrainer(
    model=model,
    args=training_args,
    train_dataset=dataset["train"],
    eval_dataset=dataset["validation"],
    processing_class=tokenizer,
    peft_config=lora_config,
)


# ============================================================
# TRAIN
# ============================================================

print("\n" + "=" * 60)
print("STARTING TRAINING")
print("=" * 60)

trainer.train()


# ============================================================
# SAVE
# ============================================================

print("\nSaving negotiator adapter...")

trainer.save_model(OUTPUT_DIR)
tokenizer.save_pretrained(OUTPUT_DIR)

print("\n" + "=" * 60)
print("TRAINING COMPLETE!")
print("=" * 60)
print("Model adapter saved to:")
print(OUTPUT_DIR)

print("\nTraining examples:", len(dataset["train"]))
print("Validation examples:", len(dataset["validation"]))

print("\nYou can now use the adapter for testing.")
