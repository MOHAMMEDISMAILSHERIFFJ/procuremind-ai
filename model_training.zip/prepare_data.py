import pandas as pd
import json
import random
import re

INPUT = r"C:\Users\NITHIN RAGUNATH\Downloads\prediction_data.csv\prediction_data.csv"

OUTPUT_TRAIN = "train.jsonl"
OUTPUT_VALID = "validation.jsonl"

SYSTEM_PROMPT = """You are an AI procurement negotiation agent.

Your job is to negotiate with vendors on behalf of a company.

Your goals are:
- Reduce unnecessary procurement cost.
- Negotiate professionally.
- Ask for discounts when appropriate.
- Compare available purchasing options.
- Protect the company's requirements.
- Never invent prices, specifications, discounts, or vendor information.
- If important information is missing, ask for it.
- Explain your reasoning clearly when making a recommendation.
"""

df = pd.read_csv(INPUT)

records = []

for text in df["Text"].dropna():

    text = str(text).strip()

    if len(text) < 30:
        continue

    # Extract product context
    context_match = re.search(
        r"Product Context:\s*(.*?)(?:\s{2,}|$)",
        text,
        re.IGNORECASE
    )

    if not context_match:
        continue

    product_context = context_match.group(1).strip()

    # Remove Product Context from remaining text
    remaining = re.sub(
        r"Product Context:\s*.*?\s{2,}",
        "",
        text,
        flags=re.IGNORECASE
    ).strip()

    if len(remaining) < 15:
        continue

    # Skip obviously malformed examples
    if len(remaining) > 2000:
        continue

    # Create procurement training example
    user_message = f"""Product context:
{product_context}

Vendor/customer message:
{remaining}

Respond as the company's procurement negotiator."""

    assistant_message = remaining

    records.append({
        "messages": [
            {
                "role": "system",
                "content": SYSTEM_PROMPT
            },
            {
                "role": "user",
                "content": user_message
            },
            {
                "role": "assistant",
                "content": assistant_message
            }
        ]
    })

# Remove duplicate examples
unique = {}

for item in records:
    key = json.dumps(item, sort_keys=True)
    unique[key] = item

records = list(unique.values())

random.seed(42)
random.shuffle(records)

split = int(len(records) * 0.9)

train = records[:split]
validation = records[split:]

with open(OUTPUT_TRAIN, "w", encoding="utf-8") as f:
    for item in train:
        f.write(json.dumps(item, ensure_ascii=False) + "\n")

with open(OUTPUT_VALID, "w", encoding="utf-8") as f:
    for item in validation:
        f.write(json.dumps(item, ensure_ascii=False) + "\n")

print("================================")
print("DATASET PREPARATION COMPLETE")
print("================================")
print("Original rows:", len(df))
print("Usable examples:", len(records))
print("Training examples:", len(train))
print("Validation examples:", len(validation))
print("Created:", OUTPUT_TRAIN)
print("Created:", OUTPUT_VALID)