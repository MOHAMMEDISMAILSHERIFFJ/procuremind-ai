import torch
from transformers import AutoTokenizer, AutoModelForCausalLM

MODEL_NAME = "Qwen/Qwen2.5-3B-Instruct"

print("Loading tokenizer...")
tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)

print("Loading model...")
model = AutoModelForCausalLM.from_pretrained(
    MODEL_NAME,
    torch_dtype=torch.float16,
    device_map="auto"
)

print("Model loaded!")
print("Device:", next(model.parameters()).device)

messages = [
    {
        "role": "system",
        "content": "You are SPENDOS AI, a professional procurement negotiation assistant."
    },
    {
        "role": "user",
        "content": "A vendor quotes ₹72,000 per laptop for 100 laptops. Our historical price is ₹65,000 and another vendor offers ₹67,000. What should we do?"
    }
]

text = tokenizer.apply_chat_template(
    messages,
    tokenize=False,
    add_generation_prompt=True
)

inputs = tokenizer(text, return_tensors="pt").to(model.device)

with torch.no_grad():
    outputs = model.generate(
        **inputs,
        max_new_tokens=200,
        temperature=0.3,
        do_sample=True
    )

answer = tokenizer.decode(
    outputs[0][inputs["input_ids"].shape[-1]:],
    skip_special_tokens=True
)

print("\n========== SPENDOS TEST ==========")
print(answer)
print("==================================")